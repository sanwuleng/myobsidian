---
type: OKR
date: 2023-12-07
aliases: 
tags:
  - review/monthly
---
## Direction

### My Core Principles
![[My Core Principles]]

### Yearly OKRs
![[Yearly OKRs 2023]]

## Last month

### Initiatives

![[Monthly Review 2023-Nov#This month]]


> [!question] Questions to ask
> Did you finish the initiatives? If so, how do you think you did? If not, what do you need to change to finish them this month?_

- 

### Other reflections


> [!question] Question to ask
> 1. How do you feel about your accomplishments? 
> 2. What prevented you from working optimally?

- 

## This month


> [!question] Question to ask
> What initiatives are you setting this month?

- [ ] 参与学习一个合适自己的法语课程
	- [ ] 找到合适的课程 W1
	- [ ] 确定学习计划，学习进度 W2
	- [ ] 开始学习 W3
- [ ] 报名准备B2考试
	- [ ] 了解报名信息 W4
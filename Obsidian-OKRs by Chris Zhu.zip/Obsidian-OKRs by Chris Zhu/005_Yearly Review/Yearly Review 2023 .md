---
type: OKR
date: 2023-12-04
aliases: 
tags:
  - review/yearly
---
## Last year

> [!question] Questions to ask
> 1. What were your OKRs last year, and how did each one go? 
> 2. What do you wish you'd done better?
### OKR 1:  


### OKR 2: 


### OKR 3:


### OKR 4: 


### OKR 5: 



## This year

[[Yearly OKRs 2023]]
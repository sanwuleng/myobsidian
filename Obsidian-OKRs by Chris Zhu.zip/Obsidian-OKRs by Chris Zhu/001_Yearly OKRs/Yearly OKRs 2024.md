---
type: OKR
date: 2023-12-07
aliases: []
tags:
  - review/OKRs
---

> [!Summary] How to do it
> 1. Write no more than 5 OKRs for this year, and create a page for each.
> 2. Put your cursor on the line you want the new OKR to be in, and then hit `⌘ + ⌃ + o` Select `Add Yearly OKR`. The new page will be created.

## Work

- [[2024 - 轻松自如地使用法语]]

## Personal

- 

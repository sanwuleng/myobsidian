通过这个库，你可以了解到我在视频中演示的系统是如何搭建的。你可以参考我的方法，结合自己的情况搭建更加适合自己的系统。

## 前序准备

以下提到的主题和插件都不是必须的。如果你喜欢我所使用的主题，你可以考虑下载并进行相关设置。所有的插件也只是为了使整个目标管理系统更加自动化，操作更加方便。如果你不会设置这些插件，使用Obsidian自带的[Templates](https://help.obsidian.md/Plugins/Templates)也可以实现类似的效果。尽量降低自己的学习成本，把更多的时间放在思考和产出上！

- 主题
	- [AnuPpuccin](https://github.com/AnubisNekhet/AnuPpuccin)
	- 对主题进行设置，需使用de插件
		- [Style Settings](https://github.com/mgmeyers/obsidian-style-settings)
		- [Hider](https://github.com/kepano/obsidian-hider) ：隐藏不需要的一些操作界面元素
- 插件
	- [Templater](https://silentvoid13.github.io/Templater/)：对模板进行设置
	- [QuickAdd](https://github.com/chhoumann/quickadd) ：快速添加置顶内容
	- [Calendar](https://github.com/liamcain/obsidian-calendar-plugin) ：日历插件，可以快速添加Daily和Weekly笔记
	- [Dataview](https://github.com/blacksmithgu/obsidian-dataview) ：对笔记按照给定的条件进行筛选
	- [Heatmap Calendar](https://github.com/Richardsl/heatmap-calendar-obsidian) ：热力图插件

## 模板

所有模板存放在Template文件夹，你可以根据自己的实际情况对这些模板进行修改，以符合你自己的需求。

- Level 1: [[My Core Principles]]
- Level 2: Yearly
	- [[yearly OKRs|Yearly OKRs]]
	- [[yearly objective|Yearly Objective]]
	- [[yearly review|Yearly Review]]
- Level 3: [[Monthly|Monthly Review]]
- Level 4: [[Weekly|Weekly Review]]
- Level 5: [[Daily]]
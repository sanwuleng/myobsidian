---
type: OKR
date: <% tp.file.creation_date("YYYY-MM-DD") %>
aliases: 
tags:
  - review/monthly
---
## Direction

### My Core Principles
![[My Core Principles]]

### Yearly OKRs
![[Yearly OKRs <% tp.date.now("YYYY") %>]]

## Last month

### Initiatives

![[Monthly Review <% tp.date.now("YYYY-MMM", "P-1M") %>#This month]]


> [!question] Questions to ask
> Did you finish the initiatives? If so, how do you think you did? If not, what do you need to change to finish them this month?_

- 

### Other reflections


> [!question] Question to ask
> 1. How do you feel about your accomplishments? 
> 2. What prevented you from working optimally?

- 

## This month


> [!question] Question to ask
> What initiatives are you setting this month?

- 
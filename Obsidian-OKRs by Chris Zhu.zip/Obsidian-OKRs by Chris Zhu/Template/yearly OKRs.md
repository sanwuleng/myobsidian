---
type: OKR
date: <% tp.file.creation_date("YYYY-MM-DD") %>
aliases: []
tags:
  - review/OKRs
---

> [!Summary] How to do it
> 1. Write no more than 5 OKRs for this year, and create a page for each.
> 2. Put your cursor on the line you want the new OKR to be in, and then hit `⌘ + ⌃ + o` Select `Add Yearly OKR`. The new page will be created.

## Work

- 

## Personal

- 

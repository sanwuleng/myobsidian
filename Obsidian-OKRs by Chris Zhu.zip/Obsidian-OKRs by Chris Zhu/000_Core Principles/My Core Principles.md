---
type: OKR
date: 2023-12-04
aliases:
  - core principles
tags:
  - review/core_principles
---
These are principles that define who I am. When faced with a decision, there are the principles that will guide me to choose a path.

## Principle 1

_Description. What does this core principle mean to me?_

What it looks like when I'm practicing this
- _One way to know I'm practicing this principle_
- 

What it looks like when I'm not practicing this
- _One way to know I'm NOT practicing this principle_
- 
---
title: <% moment(tp.file.title, "YYYY-[Q]Q").format("YYYY-[Q]Q") %>
date: <% moment(tp.file.creation_date()).format("YYYY-MM-DD HH:mm:ss") %>
lastmod: <% moment(tp.file.creation_date()).format("YYYY-MM-DD HH:mm:ss") %>
categories:
tags: quarterly-notes
aliases:
share: false
---

# <% moment(tp.file.title, "YYYY-[Q]Q").format("YYYY-[Q]Q") %>

<%*
const currentMoment = moment(tp.file.title, "YYYY-[Q]Q");
const hash = '# ';
const slash = ' / ';
const pipe = ' | ';
const leftAngle = '❮ ';
const rightAngle = ' ❯';
tR += leftAngle;
tR += '[[' + currentMoment.format('YYYY') + ']]' + slash;
tR += '[[' + currentMoment.format('YYYY-[Q]Q|[Q]Q') + ']]';
tR += rightAngle;
tR += '\n';
tR += '\n';
tR += leftAngle;
currentMoment.add(-1,'quarters');
tR += '[[' + currentMoment.format('YYYY-[Q]Q|[Q]Q') + ']]' + pipe;
currentMoment.add(1,'quarters');
tR += currentMoment.format('[Q]Q') + pipe;
currentMoment.add(1,'quarters');
tR += '[[' + currentMoment.format('YYYY-[Q]Q|[Q]Q') + ']]';
currentMoment.add(-1,'quarters');
tR += rightAngle;
tR += '\n';
tR += '\n';
tR += leftAngle;
tR += '[[' + currentMoment.format('YYYY-MM|MMMM') + ']]' + pipe;
currentMoment.add(1,'months');
tR += '[[' + currentMoment.format('YYYY-MM|MMMM') + ']]' + pipe;
currentMoment.add(1,'months');
tR += '[[' + currentMoment.format('YYYY-MM|MMMM') + ']]';
currentMoment.add(1,'months');
tR += rightAngle;
%>


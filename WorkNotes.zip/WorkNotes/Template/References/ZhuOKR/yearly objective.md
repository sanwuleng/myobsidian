---
type: OKR
date: <% tp.file.creation_date("YYYY-MM-DD") %>
aliases: []
tags:
  - review/objective
---
up:: [[Yearly OKRs <% tp.date.now("YYYY", "P1Y") %>]]
# Objective: <% tp.file.title %>

# Key Results

- 

## Related core values

- 

## Initiatives to make this happen

- 
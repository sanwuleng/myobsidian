---
type: meeting
date: <% tp.date.now("YYYY-MM-DD")%>
project: 
summary: 
tags:
---
## Attendees


## Log


## Task
- [ ] 
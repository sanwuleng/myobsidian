---
title: Areas
date: <% moment(tp.file.creation_date()).format("YYYY-MM-DD HH:mm:ss") %>
lastmod: <% moment(tp.file.creation_date()).format("YYYY-MM-DD HH:mm:ss") %>
categories: 
tags: areas
aliases: 
share: false 
---

# Areas

## Projects 🎯



## Recurring 🔁



## Archives 🗃️


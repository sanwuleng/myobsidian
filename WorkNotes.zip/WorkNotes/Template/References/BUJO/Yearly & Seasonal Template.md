
------
# Top 3 objectives (<%moment(tp.file.title).format("YYYY")%>)
- [ ] 0.1: Objective 1
- [ ] 0.2: Objective 2
- [ ] 0.3: Objective 3
Notes: 


------
## Winter (01 -- 03)
### Top 3 objectives
- [ ] 1.1: Objective 1
- [ ] 1.2: Objective 2
- [ ] 1.3: Objective 3
- [ ] preview (<%* tR+="@"%><%moment(tp.file.title).format("YYYY")%>-01-01)
- [ ] review (<%* tR+="@"%><%moment(tp.file.title).format("YYYY")%>-02-01)
- [ ] review (<%* tR+="@"%><%moment(tp.file.title).format("YYYY")%>-03-01)
- [ ] review (<%* tR+="@"%><%moment(tp.file.title).format("YYYY")%>-03-31)
Notes: 


------
## Spring (04 -- 06)
### Top 3 objectives
- [ ] 2.1: Objective 1
- [ ] 2.2: Objective 2
- [ ] 2.3: Objective 3
- [ ] preview (<%* tR+="@"%><%moment(tp.file.title).format("YYYY")%>-04-01)
- [ ] review (<%* tR+="@"%><%moment(tp.file.title).format("YYYY")%>-05-01)
- [ ] review (<%* tR+="@"%><%moment(tp.file.title).format("YYYY")%>-06-01)
- [ ] review (<%* tR+="@"%><%moment(tp.file.title).format("YYYY")%>-06-30)
Notes: 


------
## Summer (07 -- 09)
### Top 3 objectives
- [ ] 3.1: Objective 1
- [ ] 3.2: Objective 2
- [ ] 3.3: Objective 3
- [ ] preview (<%* tR+="@"%><%moment(tp.file.title).format("YYYY")%>-07-01)
- [ ] review (<%* tR+="@"%><%moment(tp.file.title).format("YYYY")%>-08-01)
- [ ] review (<%* tR+="@"%><%moment(tp.file.title).format("YYYY")%>-09-01)
- [ ] review (<%* tR+="@"%><%moment(tp.file.title).format("YYYY")%>-09-30)
Notes: 


------
## Fall (10 -- 12)
### Top 3 objectives
- [ ] 4.1: Objective 1
- [ ] 4.2: Objective 2
- [ ] 4.3: Objective 3
- [ ] preview (<%* tR+="@"%><%moment(tp.file.title).format("YYYY")%>-10-01)
- [ ] review (<%* tR+="@"%><%moment(tp.file.title).format("YYYY")%>-11-01)
- [ ] review (<%* tR+="@"%><%moment(tp.file.title).format("YYYY")%>-12-01)
- [ ] review (<%* tR+="@"%><%moment(tp.file.title).format("YYYY")%>-12-30)
Notes: 


------
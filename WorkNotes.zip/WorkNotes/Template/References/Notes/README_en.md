#README

- All template will be saved in this folder
- Use shortcut `cmd + \` or `ctrl + \` to select the template we want to insert

> [!NOTE] Rename Folder
> Please rename this folder if needed.
> Suggested name: 2. template

![[2024-10-09-README-Note management-How to manage work notes#Template]]

![[2024-10-09-README-Glossary note#Glossary]]

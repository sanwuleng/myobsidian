💩💩💩 #模板 💩💩💩

## Context

## Resource

- Link (option)
- Glossary (option)
    - [[2024-10-09-README-Glossary note]]
- Relevant query (option)

## History

- {{date: YYYY.MM.DD}} {{time}}, created by [xiaoka](https://www.xiaokaup.com/): first version
- Template: [[2024-09-02-template-Obsidian-action-add History]]
- Reference: [[What is the general format for citing articles]]

💩💩💩 #模板 💩💩💩 #记录 #日记

## 计划

planing...

<button class="sparkles">Pika pika pikachu !</button>

## 日记 Diary

- 今天做了什么 ?What did you do today?
- 做的怎么样 ? How did it go?
- 有什么问题 ?Were there any issues?
- 有更好的方式吗 ?Is there a better way?
- 明天准备怎么做 ?What's the plan for tomorrow?
- 另外，有什么有趣的事情吗 ? 印象深刻的事情呢？Also, was there anything interesting? Anything particularly memorable?

### <主题>

## Resource

- Link (option)
- Files (option)
- Glossary (option)
    - [[2024-10-09-README-Glossary note]]
- Archive (option)
- Relevant notes (option)
- Relevant query (option)

## History

- {{date: YYYY.MM.DD}} {{time}}, created by [xiaoka](https://www.xiaokaup.com/): first version
- Template: [[2024-09-02-模板-Daily-notes]]
- Reference: [[What is the general format for citing articles]]

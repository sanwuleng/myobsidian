---
cssclasses:
  - clean-embed-all
---

💩💩💩 #模板 💩💩💩 #工作 #公司

## Meeting

### Daily 10h30-11h

### Support tech (30mins~1h)

## Journal

### Work

- Done
- Doing
- Doc

Next:
task_next

### Backlog

### Issues

## Resource

- Link (option)
- Relevant notes (option)
- Relevant query (option, query code block)
- Glossary (option)
    - [[2024-10-09-README-Glossary note]]
- Files (option)
- Archive (option)

## History

- {{date: YYYY.MM.DD}} {{time}}, created by [xiaoka](https://www.xiaokaup.com/): first version
- Template: [[2024-10-09-template-Emeria-work-today-meeting-jounal-task-backlog]]
- Reference: [[What is the general format for citing articles]]
